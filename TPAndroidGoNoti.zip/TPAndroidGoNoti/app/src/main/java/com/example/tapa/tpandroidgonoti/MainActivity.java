package com.example.tapa.tpandroidgonoti;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private Button send ;
    private Button settings ;
    private EditText password;
    private EditText msgID;
    private EditText latitude;
    private EditText longitude;
    private EditText radius;
    private EditText message;
    private EditText send_url;
    OkHttpClient client = new OkHttpClient();
    private static  final int MY_PERMISSIONS_REQUEST_LOCATION = 10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send = (Button) findViewById(R.id.envoyer);
        settings = (Button) findViewById(R.id.button_settings);
        password = (EditText) findViewById(R.id.password);
        msgID = (EditText) findViewById(R.id.msgID);
        latitude = (EditText) findViewById(R.id.latitude);
        longitude = (EditText) findViewById(R.id.longitude);
        radius = (EditText) findViewById(R.id.radius);
        message = (EditText) findViewById(R.id.msgText);
        send_url = (EditText) findViewById(R.id.send_url);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();

            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);

            }
        });

        if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[] {Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        }
    }

    public void sendMessage(){
        MediaType TEXT_TYPE = MediaType.parse("application/text; charset=utf-8");

        Request request = new Request.Builder()
                .addHeader("X-Password", password.getText().toString())
                .url(""+send_url.getText()+"?id="+ msgID.getText()+ "&latitude="+latitude.getText()
                        +"&longitude="+longitude.getText()+"&radius="+radius.getText())
                .post(RequestBody.create(TEXT_TYPE,message.getText().toString()))
                .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {

                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    //le retour est effectué dans un thread différent
                    final String text = response.body().string();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("run", "run: " + text);;
                        }
                    });
                }

            });


    }


    /////////////////////////////////////////////////////Localisation /////////////////////////////////
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("permission", "onRequestPermissionsResult: permission granted");
                    //LocationManager.enableLocationSupport(getApplicationContext());
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Log.d("permission", "onRequestPermissionsResult: permission not granted");
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }
}
