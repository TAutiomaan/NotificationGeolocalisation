package com.example.tapa.tpandroidgonoti;

import android.app.IntentService;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class WatchingService extends IntentService {
    private int FOREGROUND_ID = 0 ;
    private OkHttpClient client;
    SharedPreferences settings ;
    private Circle circle;
    private final static String TAG =  "WatchingService";

    public WatchingService(){
        super(TAG);
    }

    //////////////////////////////////////////////////////////////// okhttpweb socket

    private final class EchoWebSocketListener extends WebSocketListener {
        private static final int NORMAL_CLOSURE_STATUS = 1000;

        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            webSocket.send("pushSince:0");
            //webSocket.close(NORMAL_CLOSURE_STATUS, "Goodbye !");
        }

        @Override
        public void onMessage(WebSocket webSocket, String textl) {
            output("Receiving : " + textl);
            final String text = textl;
            boolean filter = settings.getBoolean("filter", false);
            Log.d("filter", "onMessage: " + filter);
            if(filter) {
                LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

                    Location loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    // no effort since we use an already known location
                   // Log.d(TAG, "Position: " + loc.getLatitude() + "  Long : " + loc.getLongitude());
                    JSONObject jsonMsg = null;
                    double lat = 0;
                    double lon = 0;
                    double radius = 0;
                    try {
                        jsonMsg = new JSONObject(text);
                        lat = jsonMsg.getDouble("latitude");
                        lon = jsonMsg.getDouble("longitude");
                        radius = jsonMsg.getDouble("radius");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (loc != null) {
                        // location already known
                        Log.d("localisation", "Position: Connue ");
                        circle.setCenter(new LatLng(lat, lon));
                        circle.setRadius(radius);

                        float[] distance = new float[2];
                        Location.distanceBetween(loc.getLatitude(), loc.getLongitude(),
                                lat, lon, distance);

                        if (distance[0] > circle.getRadius()) {
                            //Toast.makeText(getBaseContext(), "Outside", Toast.LENGTH_LONG).show();
                            Log.d("Position", "onMessage: Outside");
                        } else {
                            //Toast.makeText(getBaseContext(), "Inside", Toast.LENGTH_LONG).show();
                            Log.d("Position", "onMessage: Inside");
                        }
                        treatMessage(text, loc);
                    } else {
                        Log.d("Ancienne Position", "Position: non Connue");
                        final boolean[] treatedMessage = {false};
                        // we must ask Android to watch for the location
                        LocationListener listener = new LocationListener() {

                            @Override
                            public void onLocationChanged(Location location) {
                                if (!treatedMessage[0]) { // if the message has not already been treated
                                    treatMessage(text, location);
                                    treatedMessage[0] = true;
                                }
                            }

                            @Override
                            public void onStatusChanged(String provider, int status, Bundle extras) {
                            }

                            @Override
                            public void onProviderEnabled(String provider) {
                            }

                            @Override
                            public void onProviderDisabled(String provider) {
                            }
                        };
                        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper());
                        Log.d("Handler", "Création du handler");
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (!treatedMessage[0]) {
                                    treatMessage(text, null);
                                    treatedMessage[0] = true;
                                }
                            }
                        }, 5000);
                    }
                }
            }

            else
                treatMessage(text, null);


        }

        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
            output("Receiving bytes : " + bytes.hex());
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            webSocket.close(NORMAL_CLOSURE_STATUS, null);
            output("Closing : " + code + " / " + reason);
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            output("Error : " + t.getMessage());
        }
    }




    /////////////////////////////////////////////////////////// ok http websocket

    public WebSocket startWatching(String url) {
        // the URL must start with ws:// or wss:// (and not http:// or https://)
        Request request = new Request.Builder().url(url).build();
        EchoWebSocketListener listener = new EchoWebSocketListener();
        WebSocket ws = client.newWebSocket(request, listener);
        return ws;
    }
    public void showNotif(String message){
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, "10")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("New message")
                .setContentText(message)
                .setLights( 0xff00ff00,1,1000)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, mBuilder.build());
    }

    private void output(final String txt) {

        Log.d("Message", txt);
    }

    private void treatMessage(String text, Location loc){
        Log.d("TreatMessage", "traitement du messgae");
        boolean notification = settings.getBoolean("notification", true);
        if (notification){
            try {
                JSONObject jsonMsg = new JSONObject(text);
                showNotif(jsonMsg.getString("content"));
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    protected  void onHandleIntent(Intent intent){
        startForeground(FOREGROUND_ID,
                buildForegroundNotification());
        settings = PreferenceManager.getDefaultSharedPreferences(this);
        Log.d("Service", "Je suis dans le service");
        client = new OkHttpClient();
        final WebSocket[] ws = {null};
        //final String url = "ws://echo.websocket.org";
        String url = settings.getString("url","ws://192.168.43.245:1818/notifications/android");
        //final String url = "ws://192.168.43.245:1818/notifications/android";

        ws[0] = startWatching(url);


    }

    private Notification buildForegroundNotification() {
        NotificationCompat.Builder b=new NotificationCompat.Builder(this);

        b.setOngoing(true)
                .setContentTitle("WatchingService")
                .setContentText("Waiting for messages")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setTicker("...");

        return(b.build());
    }


}
