package com.example.tapa.tpandroidgonoti;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    private Switch service , notification, filter;
    private Button save, send;
    private EditText url;
    SharedPreferences settings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        settings = PreferenceManager.getDefaultSharedPreferences(this);
        final SharedPreferences.Editor editor = settings.edit();

        service = (Switch) findViewById(R.id.switch__service);
        notification = (Switch) findViewById(R.id.switch_notification);
        filter = (Switch) findViewById(R.id.switch_filtrage);
        save = (Button) findViewById(R.id.button_save);
        send = (Button) findViewById(R.id.button_send);
        url = (EditText) findViewById(R.id.editText_url);

        service.setChecked(settings.getBoolean("service", true));
        notification.setChecked(settings.getBoolean("notification", true));
        filter.setChecked(settings.getBoolean("filter", true));
        url.setText(settings.getString("url","ws://192.168.43.245:1818/notifications/android"));

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putBoolean("service", service.isChecked());
                editor.putBoolean("notification", notification.isChecked());
                editor.putBoolean("filter", filter.isChecked());
                editor.putString("url",url.getText().toString());
                editor.commit();
                if(service.isChecked()){
                    Log.d("Service Switch", "is checked ");
                    Log.d("server URL", url.getText().toString());
                    Intent i = new Intent(SettingsActivity.this, WatchingService.class);
                    startService(i);
                }else{
                    Intent i = new Intent(SettingsActivity.this, WatchingService.class);
                    stopService(i);
                }
            }
        });



        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j =  new Intent(SettingsActivity.this, MainActivity.class);
                startActivity(j);
            }
        });

        registerReceiver();

    }

    private void registerReceiver()
    {
        try
        {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(NetworkChangeReceiver.NETWORK_CHANGE_ACTION);
            registerReceiver(internalNetworkChangeReceiver, intentFilter);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    protected void onDestroy()
    {
        try
        {
            // Make sure to unregister internal receiver in onDestroy().
            unregisterReceiver(internalNetworkChangeReceiver);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        super.onDestroy();
    }

    /**
     * This is internal BroadcastReceiver which get status from external receiver(NetworkChangeReceiver)
     * */
    InternalNetworkChangeReceiver internalNetworkChangeReceiver = new InternalNetworkChangeReceiver();
    class InternalNetworkChangeReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent) {

            Toast.makeText(SettingsActivity.this, intent.getStringExtra("status"),
                    Toast.LENGTH_LONG).show();
        }
    }
}
